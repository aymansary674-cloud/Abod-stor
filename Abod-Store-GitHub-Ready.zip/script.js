const products=[
{id:1,name:"سماعات لاسلكية",price:149,icon:"🎧",desc:"صوت واضح وبطارية ممتازة"},
{id:2,name:"ساعة ذكية",price:229,icon:"⌚",desc:"تصميم أنيق ومزايا متعددة"},
{id:3,name:"حقيبة عصرية",price:119,icon:"🎒",desc:"خفيفة وعملية للاستخدام اليومي"},
{id:4,name:"هاتف ذكي",price:899,icon:"📱",desc:"أداء سريع وشاشة عالية الجودة"},
{id:5,name:"حذاء رياضي",price:199,icon:"👟",desc:"راحة وأناقة للرياضة والمشي"},
{id:6,name:"كاميرا",price:649,icon:"📷",desc:"صور واضحة وتصميم مميز"},
{id:7,name:"لوحة مفاتيح",price:159,icon:"⌨️",desc:"مناسبة للعمل والألعاب"},
{id:8,name:"نظارة شمسية",price:89,icon:"🕶️",desc:"تصميم عصري وخفيف"}];

let cart=JSON.parse(localStorage.getItem("abodCart")||"[]");
const grid=document.getElementById("productsGrid"),search=document.getElementById("search");
function renderProducts(list=products){
 grid.innerHTML=list.map(p=>`<article class="product"><div class="product-img">${p.icon}</div><div class="product-body"><h3>${p.name}</h3><p>${p.desc}</p><div class="price">${p.price} ر.س</div><button class="primary add" onclick="addToCart(${p.id})">أضف للسلة</button></div></article>`).join("")||"<p>لا توجد منتجات.</p>";
}
function addToCart(id){cart.push(id);save();openCart()}
function removeFromCart(i){cart.splice(i,1);save()}
function save(){localStorage.setItem("abodCart",JSON.stringify(cart));renderCart()}
function renderCart(){
 document.getElementById("cartCount").textContent=cart.length;
 const items=document.getElementById("cartItems");
 if(!cart.length){items.innerHTML="<p>السلة فارغة حالياً.</p>";document.getElementById("cartTotal").textContent="0";return}
 let total=0;
 items.innerHTML=cart.map((id,i)=>{const p=products.find(x=>x.id===id);total+=p.price;return `<div class="cart-row"><span>${p.icon} ${p.name}</span><span>${p.price} ر.س <button onclick="removeFromCart(${i})">حذف</button></span></div>`}).join("");
 document.getElementById("cartTotal").textContent=total;
}
function openCart(){document.getElementById("cart").classList.add("open");document.getElementById("overlay").classList.add("open")}
function closeCart(){document.getElementById("cart").classList.remove("open");document.getElementById("overlay").classList.remove("open")}
document.getElementById("cartBtn").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
document.getElementById("overlay").onclick=closeCart;
search.addEventListener("input",e=>renderProducts(products.filter(p=>p.name.includes(e.target.value))));
document.getElementById("checkout").onclick=()=>alert(cart.length?"تم تجهيز السلة. اربط زر الطلب بواتساب أو نظام الدفع الخاص بك.":"أضف منتجاً إلى السلة أولاً.");
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();